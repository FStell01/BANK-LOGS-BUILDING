// generated-from:9833c29dfe74d5afe8c5ab0dc296e228f51d6def781f3a68f18884d149cad417 DO NOT REMOVE, DO UPDATE

// stub to get pkger to work
package achgateway

import (
	"github.com/markbates/pkger"
)

// Add in all includes that pkger should embed into the application here
var _ = pkger.Include("/configs/config.default.yml")
var _ = pkger.Include("/migrations/")
