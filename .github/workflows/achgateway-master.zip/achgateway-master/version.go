// Copyright 2020 The Moov Authors
// Use of this source code is governed by an Apache License
// license that can be found in the LICENSE file.
// generated-from:891e377361929cf0fa2e83c6a243ccb2300edd5dbb1d2014a83e01696bfa0312 DO NOT REMOVE, DO UPDATE

package achgateway

var Version string
